#!/bin/bash

unset IFS

#### Advance preparation ####

### 1) copy the data
cp -r /localdisk/data/BPSM/Assignment1 .

### 2)Assign variable names to the original data files or directories

# NOTE: If you have different file names or different directories
# you have to reset these variables before running this script

ProjectRootDir=$(pwd)/Assignment1
Genebed=$(pwd)/Assignment1/Tbbgenes.bed
Genomefasta=$(pwd)/Assignment1/Tbb_genome/Tb927_genome.fasta
samplefile=$(pwd)/Assignment1/fastq/fqfiles

### 3) make new directories to store different results in different processes

cd ${ProjectRootDir} # make sure I'm always at the right place
mkdir -p fastqc_result # make a new directory to save the result of
mkdir -p tmp_result # to save output files generate by bowtie2, samtools and bedtools

# The -p option is useful when you using mkidr to creat a specified directory include the path information. 
# If current directory is ~/, and I want to build a new directory ~/Assignment1/tem_result,
# -p will make it success when Assignment1 is not exist.



#### fastqc: Quality Control ####

fastqc -o fastqc_result -t 6 ${ProjectRootDir}/fastq/*fq.gz
# -o: indicate the output directory
# -t: the number of threads

echo -e "Fastqc quality control for all samples has been completed."


#### mapping to reference genome ####

# meke sure in the right working directory
cd ${ProjectRootDir} 

### 1) build index
gunzip ${Genomefasta}.gz # decompression the file
echo -e "Now is building the genome index."
bowtie2-build ${Genomefasta} tmp_result/index
echo -e "Genome index is built."

### 2) Aligning pairs
cd ${ProjectRootDir}/tmp_result

# a loop 
while read Number Condition Read1 Read2
do
echo -e "Aligning ${Read1} and ${Read2}... "
bowtie2 --threads 6 -x index \
-1 ../fastq/${Read1} \
-2 ../fastq/${Read2} \
-S ${Number}_${Condition}.sam

echo -e "${Number}_${Condition}.sam have been genrated, then execute sam2bam, samtools sort and index."

### 3) sam2bam
samtools view -S -b ${Number}_${Condition}.sam > ${Number}_${Condition}.bam 
echo -e "${Number}_${Condition}.bam is generated."
# -S Input is in SAM format
# -b Output in BAM format

### 4) samtools sort
samtools sort ${Number}_${Condition}.bam -o ${Number}_${Condition}.sorted.bam
echo -e "${Number}_${Condition}.sorted.bam is generated."

### 5) samtools index
samtools index ${Number}_${Condition}.sorted.bam
echo -e "${Number}_${Condition}.sorted.bam.bai is generated."
done < ${samplefile}



#### Using `bedtools multicov` counts the alignments ####

# creat a variance to store the order of input sorted sam files

sortedBAMs=$(ls *sorted.bam | sed 's/\t/\n/g' | sort -k1,1n | sed ':a;N;s/\n/ /g;ta')
## ls *sorted.bam: list all the sorted bam file
## sed 's/\t/\n/g': present as a column
## sort -k1,1n: sort it as a numeric, to make sure in a right order
## sed ':a;N;s/\n/ /g;ta': transfer a long single column to a line, separate by space
## the same as the next command



# creat a varaince to store the name which I want to add as a header for my final outcome file
# and the order of header is as the same as the file input order

sampelCountsHead=$(ls *sorted.bam | sed 's/\t/\n/g' | sort -k1,1n | cut -d "." -f 1 | sed ':a;N;s/\n/\t/g;ta')



# caculate the reads count, and add a header for the matrix

echo -r "Computing the reads count..."

bedtools multicov -bams ${sortedBAMs} -bed ${Genebed} | \
awk '{FS=OFS="\t"}BEGIN{print "chromName","chromStart","chromEnd","geneName","geneType","Strand", \
"'"${sampelCountsHead}"'"};{print}'  > Readcounts.txt
## using a variable in awk, you may have to use like "'"${sampelCountsHead}"'"



# compute the statistical mean, and get the 3-column file

tail -n +2 Readcounts.txt | awk 'BEGIN{FS=OFS="\t"}{sum1=$7+$8+$9; sum2=$10+$11+$12;}{print $4,sum1/3,sum2/3}' | \
sed '1 igeneName\tmean_ReadCounts_Condition1\tmean_ReadCounts_Condition2' > Readcounts.mean.txt
## sed '1 i.....': Add a line before the first line of the file.

echo -e "Reads count matrix is generated."
